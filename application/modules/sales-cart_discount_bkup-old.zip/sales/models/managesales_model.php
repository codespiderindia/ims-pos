<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Managesales_model extends CI_Model {

	function __construct(){
	
		parent::__construct();
		$this->load->library('email');
	}

 	

  
 
	function get_search_suggestions($search, $filters = array('is_deleted' => FALSE, 'search_custom' => FALSE), $unique = FALSE, $limit = 25)
	{
		$suggestions = array();

		$this->db->select('product_id, product_name, product_barcode_text');
		$this->db->from('product');
		$this->db->like('product_name', $search);
		$this->db->or_like('product_barcode_text', $search);
		$this->db->order_by('product_name', 'asc');
		foreach($this->db->get()->result() as $row)
		{
			$prd_name=$row->product_barcode_text." (".$row->product_name.")";
			$suggestions[] = array('value' => $row->product_id, 'label' => $prd_name);
		}

		//only return $limit suggestions
		if(count($suggestions > $limit))
		{
			$suggestions = array_slice($suggestions, 0,$limit);
		}

		return $suggestions;
	}

	function getItemInfoByID($itmID){
		$this->db->select("product_id,product_name,product_tax,product_price,gst_rate,product_unit");
		$this->db->from('product');
		$this->db->where('product_id',$itmID);
		$this->db->or_where('product_barcode_text',(int) $itmID);

		$query = $this->db->get();
		if($query->num_rows() > 0)
			return $query->row_array();
		else
			return FALSE;
	}

	
	function create_sale($sData){
		//var_dump($this->session->userdata('cart_contents'));
		$cart_contents=$this->session->userdata('cart_contents');
		$cart_items=$this->cart->contents();
		$uInfo=$this->session->userdata('sales_session_info');
		
		//var_dump($uInfo);
		$paymentInfo=$this->session->userdata('_payment_options_amount');

		//var_dump($paymentInfo);exit;

		$total_items=$cart_contents['total_items'];
		$cart_total=$cart_contents['cart_total'];
		$cart_total_inc_discount_tax=$cart_contents['cart_total_inc_discount_tax'];

	// Insert sale info	
		$sale_data=array(
				'employee_ID' => $uInfo['user_ID'],
				'customer_ID' =>1,
				'company_ID' => $uInfo['comp_code'],
				'location_ID' => $uInfo['location'],
				'store_ID' => $uInfo['store'],
				'total_items' => $total_items,
				'sub_total' => $cart_total,
				'total' => $cart_total_inc_discount_tax,
				'remark' => $sData['remark'],
			);
		$this->db->insert('sale', $sale_data);
        $saleID = $this->db->insert_id();
    // Ends Here

        if(isset($saleID) && !empty($saleID)){

        	
        	if(isset($cart_items) && !empty($cart_items)){
				foreach ($cart_items as $item) {
					//echo $item['name'];

				// Insert Sale Items
					$itemData=array(
						'sale_ID' => $saleID,
						'product_ID' => $item['id'],
						'product_detail' => $item['name'],
						'quantity' => $item['qty'],
						'item_cost_price' => $item['price'],
						'item_unit_price' => round($item['subtotal_inc_discount_tax']/$item['qty'],2),
						'discount_per' => $item['discount'],
						'tax_per' => $item['tax'],
						'item_subtotal' => $item['subtotal_inc_discount_tax']
					);
					$this->db->insert('sale_items', $itemData);
				
				}

				// Insert Sale Payments
				foreach ($paymentInfo as $key=>$val) {

					$payData=array(
						'sale_ID' => $saleID,
						'payment_method' => $key,
						'payment_amount' => $val,
						'code_if_any' => '',
						
					);
					$this->db->insert('sale_payments`', $payData);
					//var_dump($item);exit;

				}
        	}
        	
			
        	
        }else{
        	return FALSE;
        }
		
		return $saleID;
	}

	function getSaleDetailByID($saleID){
		$this->db->select("*");
		$this->db->from('sale');
		$this->db->where('sale_ID',$saleID);
		$query = $this->db->get();
		if($query->num_rows() > 0)
			return $query->row_array();
		else
			return FALSE;

	}

	function getSaleItemsByID($saleID){
		$this->db->select("*");
		$this->db->from('sale_items');
		$this->db->join('product', 'product.product_id = sale_items.product_ID', 'left');

		$this->db->where('sale_ID',$saleID);
		$query = $this->db->get();
		if($query->num_rows() > 0)
			return $query->result_array();
		else
			return FALSE;

	}

	function getSalePaymentsByID($saleID){
		$this->db->select("*");
		$this->db->from('sale_payments');
		$this->db->where('sale_ID',$saleID);
		$query = $this->db->get();
		if($query->num_rows() > 0)
			return $query->result_array();
		else
			return FALSE;

	}


	
  	
}

//https://infowindtech@git.webgaff.com/abiola/webgaff_template.git

//git clone https://infowindtech:infowind@123@git.webgaff.com/abiola/webgaff_template.git
