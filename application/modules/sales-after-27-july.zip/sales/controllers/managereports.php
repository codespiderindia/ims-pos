<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class ManageReports extends CI_Controller {

	function __construct()
		{		
			parent::__construct();
			header("cache-Control: no-store, no-cache, must-revalidate");
			header("cache-Control: post-check=0, pre-check=0", false);
			header("Pragma: no-cache");
			header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
			global $uInfo;

			$this->load->library('cart');
			$uInfo=$this->session->userdata('sales_session_info');
			$this->load->helper('url');
			$this->load->model('common');
			$this->load->model('managesales_model');
			if (!($this->session->userdata('sales_session_info'))) {
				redirect(base_url().'sales/login');
			}
		}
	
	 function index()
	{
		
		global $uInfo;

		if (isset($uInfo) && !empty($uInfo)) {
			$data['title'] = 'Dashboard | Sales';
			$data['cart_items'] = $this->cart->contents(); 
			$this->load->view('managesales/addOrder', $data);
		}
		
	}

	function mysale(){
		$data['title'] = 'Dashboard | Sales';
		$this->load->view('managereports/mysale',$data);
	}

	
	

	


	
	
	

	

   function complete_sale(){

	  if($this->input->post())
	   {
	     	$sData=array(
				'remark' => $this->input->post('sale_comment'),
				
			);
	     	$saleID=$this->managesales_model->create_sale($sData);
	     	if(isset($saleID) && !empty($saleID)){
	     		//$this->cart->destroy();
	     		$saleData=array();
	     		
				$saleData['sale_detail']=$this->managesales_model->getSaleDetailByID($saleID);
				$saleData['sale_items']=$this->managesales_model->getSaleItemsByID($saleID);
				$saleData['sale_payments']=$this->managesales_model->getSalePaymentsByID($saleID);
				
	     		//var_dump($this->session->userdata('_payment_options_amount'));
	     		//var_dump($this->cart->contents());
	     		//var_dump($this->session->userdata('cart_contents'));
				$this->load->view('managesales/pdf',$saleData);
	     		
	     	}
		
		}
		else
		{
		  redirect(base_url().'sales/managesales');
		}  

   }
   

}

