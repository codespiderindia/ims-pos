<table id="cart_items"  class="table table-striped table-bordered table-hover">
                                                        <thead>
                                                                <tr>
                                                                        <th class="center">#</th>
                                                                        <th class="center">Item Name</th>
                                                                        <th class="center">Quantity</th>
                                                                        <th class="center">Unit</th>
                                                                        <th class="center">Rate</th>
                                                                        <th class="center">Dis.(%)</th>
                                                                        <!-- <th class="center">Dis.</th> -->
                                                                        <th class="center">Tax(%)</th>
                                                                        <!-- <th class="center">Tax</th> -->
                                                                        <th class="center">Amount</th>

                                                                
                                                                </tr>
                                                        </thead>

                                                        <tbody>
                                                        <?php // foreach ($cart_items as $row): ?>
                                                                <tr>
                                                                        <td>
                                                                               
                                        
                                       #
                                                                                
                                                                        </td>
                                                                        <td><strong></strong><br/>
</td>
                                                                        <td style="text-align: right;">

                                                                       
                                                                                
                                                                               sdfs
                                                                        
                                                                        

                                                                        </td>
                                                                        <td style="text-align: left;"></td>
                                                                        <td style="text-align: right;">

                                                                       
                                                                                
                                                                                sdfsd
                                                                                 
                                                                        
                                                                        </td>
                                                                        <td style="text-align: right;">
                                                                               
                                                                                
                                                                               sdfsdf
                                                                       

                                                                        </td>
                                                                       <!--  <td style="text-align: right;">0</td> -->
                                                                        <td style="text-align: right;">
                                                                              
                                                                                
                                                                                sdfsdf
                                                                    

                                                                        <!-- <td style="text-align: right;">0</td> -->   
                                                                        <td style="text-align: right;">
                                                                           sda
                                                                        </td>
                                                                </tr>
                                                        <?php //endforeach; ?>
                                                                
                                                        </tbody>
                                                </table>

