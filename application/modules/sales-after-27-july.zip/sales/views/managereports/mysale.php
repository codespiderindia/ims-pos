<?php $this->load->view('include/layout_header'); ?>




<?php $uinfo = $this->session->userdata('sales_session_info');?>
<style type="text/css">
	
	.error{

		border: 1px solid red !important;

	}
</style>
  

<div class="page-content">
   <div class="page-header position-relative">
      <h1 class="headingThemeColor">Sale Info.</h1>
      <?php if($this->session->flashdata('error_msg')): ?>
      <div class="alert alert-error">
         <button type="button" class="close" data-dismiss="alert"> <i class="icon-remove"></i> </button>
         <strong> <i class="icon-remove"></i> Error! </strong> <?php echo $this->session->flashdata('error_msg'); ?> <br />
      </div>
      <?php endif; ?>
      <?php if($this->session->flashdata('success_msg')): ?>
      <div class="alert alert-block alert-success ">
         <button type="button" class="close" data-dismiss="alert"> <i class="icon-remove"></i> </button>
         <p> <strong> <i class="icon-ok"></i> Done! </strong> <?php echo $this->session->flashdata('success_msg'); ?> </p>
      </div>
      <?php endif; ?>
   </div>
   <!--/.page-header-->
   
   <!--/.row-fluid-->
   <div class="row-fluid">
		<div class="span12">

		




			<div class="widget-box">
				<div class="widget-header">
					<h4 class="smaller">
						Order Information
						
					</h4>
				</div>

				<div class="widget-body">
				
					<div class="widget-main ">
					<section>
						<table>
						<tr>
							<td width="100px;"> <label style="margin-top: -10px;text-align: right;ext-align: right;" >Date : &nbsp;</label> </td>
							<td><input id="reportrange" name="reportrange" type="text" placeholder="Type something…" ></td>
							<td width="150px;"> 
							<button>Show</button>
							</td>
							
							
							
							
							
					</table>

						
					</section>
					
					</div>
					
				</div>
			</div>
		</div>
	</div>

   <div class="row-fluid">
		<div class="span12 >
			<!--PAGE CONTENT BEGINS-->

			

						<div class="widget-box">
				<div class="widget-header">
					<h4 class="smaller">
						Item Information
					</h4>
				</div>

				<div class="widget-body">
					<div class="widget-main ">
						
<div id="div_cart">
							
								<?php $this->load->view('managereports/sale_report_view'); ?>
						</div>
						
						<div class="clear"></div>
					</div>
					
				</div>
			</div>
						
						
						
					
			

			<!--PAGE CONTENT ENDS-->
		</div><!--/.span-->
				<!-- <div class="span3" style="width: 20.077%; margin-left: 0.5%;">
					<div id="div_cart_total">
					
						<?php //$this->load->view('managesales/cart_total'); ?>	
					</div>
				
				
				</div> -->
				
			</div>
		</div>
	</div><!--/.row-fluid-->
</div>


<!--/.page-content-->
<?php $this->load->view('include/layout_footer');?>

</body>
</html>



<script src="https://code.jquery.com/jquery-1.11.1.js"></script>
<script src="<?php echo base_url();?>assets/js/jquery.form.min.js"></script>
  <script src="https://code.jquery.com/ui/1.11.1/jquery-ui.js"></script>

<script src="<?php echo base_url();?>assets/js/browser/browser.js"></script>


<!-- Date picker -->
<!-- Include Required Prerequisites -->
<script type="text/javascript" src="//cdn.jsdelivr.net/jquery/1/jquery.min.js"></script>
<script type="text/javascript" src="//cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/bootstrap/3/css/bootstrap.css" />
 
<!-- Include Date Range Picker -->
<script type="text/javascript" src="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.js"></script>
<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.css" />
<!-- Date picker end -->
<script type="text/javascript">

	$(function($) {

		/*Date Picker*/
			var start = moment().subtract(29, 'days');
    var end = moment();

    function cb(start, end) {
        $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
    }

    $('#reportrange').daterangepicker({
        startDate: start,
        endDate: end,
        ranges: {
           'Today': [moment(), moment()],
           'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
           'Last 7 Days': [moment().subtract(6, 'days'), moment()],
           'Last 30 Days': [moment().subtract(29, 'days'), moment()],
           'This Month': [moment().startOf('month'), moment().endOf('month')],
           'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        }
    }, cb);

cb(start, end);
		/*Date Picker End*/
	});



/*http://www.daterangepicker.com/#examples*/
	

</script>



 

	